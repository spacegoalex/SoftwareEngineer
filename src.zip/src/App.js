import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useState } from 'react';

import Home from './pages/Home';
import Recipe from './pages/Recipe';
import Workout from './pages/Workout';
import BMI from './pages/BMI';
import DailyActivity from './pages/DailyActivity';
import Chatbot from './pages/Chatbot';
import CalorieCalculator from './pages/CalorieCalculator';
import Summary from './pages/Summary';
import Navigation from './components/Navigation';
import './style.css';

function App() {
  const [foodCalories, setFoodCalories] = useState(0);
  const [goalCalories, setGoalCalories] = useState(2000);
  const [exerciseCalories, setExerciseCalories] = useState(200);

  const handleAddFood = (amount) => {
    setFoodCalories(prev => prev + amount);
  };

  const handleAddExercise = (amount) => {
    setExerciseCalories(prev => prev + amount);
  };

  const handleResetAll = () => {
    setFoodCalories(0);
    setExerciseCalories(0);
    setGoalCalories(0);
  };

  return (
    <Router>
      <div className="app-container">
        <Routes>
          <Route path="/" element={<Navigate to="/home" />} />
          <Route path="/home" element={
            <Home 
              foodCalories={foodCalories} 
              goalCalories={goalCalories}
              exerciseCalories={exerciseCalories}
            />
          } />
          <Route path="/recipe" element={<Recipe />} />
          <Route path="/workout" element={<Workout />} />
          <Route path="/bmi" element={<BMI />} />
          <Route path="/activity" element={
            <DailyActivity onAddExercise={handleAddExercise} />
          } />
          <Route path="/chatbot" element={<Chatbot />} />
          <Route path="/calorie" element={<CalorieCalculator onAddFood={handleAddFood} />} />
          <Route path="/summary" element={
            <Summary
              foodCalories={foodCalories}
              goalCalories={goalCalories}
              exerciseCalories={exerciseCalories}
              setGoalCalories={setGoalCalories}
              setExerciseCalories={setExerciseCalories}
              setFoodCalories={setFoodCalories}
              onResetAll={handleResetAll}
            />
          } />
        </Routes>
        <Navigation />
      </div>
    </Router>
  );
}

export default App;
