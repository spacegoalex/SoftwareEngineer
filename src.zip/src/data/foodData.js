// src/data/foodData.js

export const FOOD_DATA = [
  { name: "Nasi putih", unit: "100g", calories: 175 },
  { name: "Nasi merah", unit: "100g", calories: 110 },
  { name: "Kentang rebus", unit: "100g", calories: 87 },
  { name: "Ubi jalar", unit: "100g", calories: 86 },
  { name: "Singkong", unit: "100g", calories: 160 },
  { name: "Roti putih", unit: "1 iris", calories: 66 },
  { name: "Roti gandum", unit: "1 iris", calories: 67 },
  { name: "Mi goreng instan", unit: "80g", calories: 350 },

  { name: "Dada ayam goreng (dengan kulit)", unit: "100g", calories: 216 },
  { name: "Dada ayam goreng (tanpa kulit)", unit: "100g", calories: 184 },
  { name: "Bebek goreng", unit: "100g", calories: 286 },
  { name: "Ikan kembung", unit: "100g", calories: 167 },
  { name: "Ikan lele goreng", unit: "100g", calories: 105 },
  { name: "Ikan salmon panggang", unit: "100g", calories: 171 },
  { name: "Udang goreng tepung", unit: "100g", calories: 150 },
  { name: "Bakso sapi", unit: "100g", calories: 202 },
  { name: "Chicken nugget", unit: "100g", calories: 297 },

  { name: "Semangka", unit: "100g", calories: 30 },
  { name: "Melon", unit: "100g", calories: 34 },
  { name: "Alpukat", unit: "100g", calories: 322 },
  { name: "Anggur", unit: "100g", calories: 69 },
];
