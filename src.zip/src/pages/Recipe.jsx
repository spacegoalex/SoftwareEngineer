import { useState, useEffect } from "react";

const initialRecipes = [
  { emoji: "🥗", title: "Salad Alpukat & Quinoa", time: "15 min", calories: "320 kcal" },
  { emoji: "🍲", title: "Sup Ayam & Sayuran", time: "30 min", calories: "280 kcal" },
  { emoji: "🥩", title: "Steak Dada Ayam Panggang", time: "25 min", calories: "410 kcal" },
  { emoji: "🥪", title: "Sandwich Telur & Alpukat", time: "10 min", calories: "350 kcal" },
];

function Recipe() {
  const [search, setSearch] = useState("");
  const [recipes, setRecipes] = useState(initialRecipes);
  const [selected, setSelected] = useState(null);

  const filtered = recipes.filter(r =>
    r.title.toLowerCase().includes(search.toLowerCase()) ||
    r.time.toLowerCase().includes(search.toLowerCase()) ||
    r.calories.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="content">
      {/* Search Bar */}
      <div className="search-container">
        <span className="search-icon">🔍</span>
        <input
          type="text"
          className="search-input"
          placeholder="Cari resep sehat..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        {search && (
          <span className="clear-search" onClick={() => setSearch("")}>
            ✕
          </span>
        )}
      </div>

      <h3 style={{ marginBottom: "15px" }}>Rekomendasi Resep</h3>

      {filtered.length > 0 ? (
        filtered.map((r, i) => (
          <div
            key={i}
            className="card recipe-item"
            onClick={() => setSelected(r)}
            style={{ cursor: "pointer" }}
          >
            <div className="recipe-image">{r.emoji}</div>
            <div className="recipe-info">
              <div className="recipe-title">{r.title}</div>
              <div className="recipe-details">
                <div className="recipe-stat">⏰ <span>{r.time}</span></div>
                <div className="recipe-stat">🔥 <span>{r.calories}</span></div>
              </div>
            </div>
          </div>
        ))
      ) : (
        <div className="not-found-message">
          Resep tidak ditemukan. Coba kata kunci lain.
        </div>
      )}

      {/* Modal */}
      {selected && (
        <div className="modal" onClick={() => setSelected(null)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <span className="close" onClick={() => setSelected(null)}>×</span>
            <h3 style={{ textAlign: "center" }}>{selected.title}</h3>
            <div style={{ fontSize: "40px", textAlign: "center", margin: "10px 0" }}>
              {selected.emoji}
            </div>
            <p><strong>Waktu Persiapan:</strong> {selected.time}</p>
            <p><strong>Kalori:</strong> {selected.calories}</p>
            <p style={{ marginTop: 10 }}><strong>Bahan:</strong></p>
            <ul>
              <li>Bahan utama sesuai resep {selected.title}</li>
              <li>Bumbu dan rempah secukupnya</li>
              <li>Bahan pendukung lainnya</li>
            </ul>
            <p><strong>Instruksi:</strong> Cara membuat {selected.title} dengan mudah dan lezat.</p>
          </div>
        </div>
      )}
    </div>
  );
}

export default Recipe;
