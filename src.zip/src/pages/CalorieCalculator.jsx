// src/pages/CalorieCalculator.jsx
import { useState } from "react";
import { FOOD_DATA } from "../data/foodData"; // buat file ini nanti

function CalorieCalculator({ onAddFood }) {
  const [query, setQuery] = useState("");
  const [selectedFood, setSelectedFood] = useState(null);
  const [grams, setGrams] = useState("");
  const [result, setResult] = useState(null);

  const handleSearch = (e) => {
    const value = e.target.value;
    setQuery(value);
    const match = FOOD_DATA.find(item =>
      item.name.toLowerCase().includes(value.toLowerCase())
    );
    setSelectedFood(match || null);
    setResult(null);
  };

  const handleCalculate = () => {
    if (!selectedFood || !grams || grams <= 0) return;
    const kaloriPerGram = selectedFood.calories / parseFloat(selectedFood.unit.replace(/[^0-9]/g, ""));
    const totalCalories = Math.round(kaloriPerGram * grams);
    setResult(totalCalories);
    if (onAddFood) {
      onAddFood(totalCalories, selectedFood.name);
    }
  };

  return (
    <div className="content calorie-calculator">
      <div className="back-button" onClick={() => window.history.back()}>
        <div className="back-icon">←</div>
        <div>Kembali</div>
      </div>

      <div className="bmi-title">Calorie Calculator</div>
      <div className="bmi-subtitle">Cari makanan dan hitung kalori berdasarkan gram</div>

      <div className="input-group">
        <label>Cari makanan</label>
        <input
          type="text"
          value={query}
          onChange={handleSearch}
          placeholder="Contoh: nasi putih"
        />
      </div>

      {selectedFood && (
        <div className="selected-food">
          <p><strong>{selectedFood.name}</strong> ({selectedFood.unit}) = {selectedFood.calories} kkal</p>
        </div>
      )}

      <div className="input-group">
        <label>Berapa gram?</label>
        <input
          type="number"
          value={grams}
          onChange={(e) => setGrams(e.target.value)}
          placeholder="Contoh: 150"
        />
      </div>

      <button className="calculate-btn" onClick={handleCalculate}>Hitung Kalori</button>

      {result && (
        <div className="bmi-calories" style={{ marginTop: "20px" }}>
          Total estimasi kalori: <strong>{result} kkal</strong>
        </div>
      )}
    </div>
  );
}

export default CalorieCalculator;
