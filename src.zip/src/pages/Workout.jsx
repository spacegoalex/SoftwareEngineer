import { useState } from "react";

const workouts = [
  {
    title: "Full Body HIIT",
    duration: "30 min",
    calories: "300 kcal",
    category: "weightloss",
    color: "#ff6b6b"
  },
  {
    title: "Yoga untuk Pemula",
    duration: "20 min",
    calories: "150 kcal",
    category: "maintain",
    color: "#3ddad7"
  },
  {
    title: "Sumo Squat Deadlift",
    duration: "40 min",
    calories: "400 kcal",
    category: "bodybuilding",
    color: "#1c1c1c"
  },
  {
    title: "Upper Body Strength",
    duration: "35 min",
    calories: "350 kcal",
    category: "bodybuilding",
    color: "#f06595"
  },
  {
    title: "Bulking Workout",
    duration: "25 min",
    calories: "500 kcal",
    category: "weightgain",
    color: "#845ef7"
  },
];

const categories = [
  { label: "Semua", value: "all" },
  { label: "Weight Loss", value: "weightloss" },
  { label: "Maintain", value: "maintain" },
  { label: "Weight Gain", value: "weightgain" },
  { label: "Bodybuilding", value: "bodybuilding" },
];

function Workout() {
  const [selectedCategory, setSelectedCategory] = useState("all");

  const filtered = selectedCategory === "all"
    ? workouts
    : workouts.filter((w) => w.category === selectedCategory);

  return (
    <div className="content" id="workout-page">
      <div className="header">
        <div className="profile-pic">👤</div>
        <div>
          <div className="greeting">Hello,</div>
          <div className="user-name">Budi Siregar</div>
        </div>
      </div>

      {/* Scrollable category */}
      <div className="category-scroll">
        {categories.map((cat) => (
          <div
            key={cat.value}
            className={`category-chip ${selectedCategory === cat.value ? "active" : ""}`}
            onClick={() => setSelectedCategory(cat.value)}
          >
            {cat.label}
          </div>
        ))}
      </div>

      {/* Workout Cards */}
      {filtered.map((item, idx) => (
        <div
          key={idx}
          className="workout-box"
          style={{ backgroundColor: item.color }}
        >
          <div className="workout-title">{item.title}</div>
          <div className="workout-meta">
            ⏱ {item.duration} &nbsp; 🔥 {item.calories}
          </div>
        </div>
      ))}
    </div>
  );
}

export default Workout;
