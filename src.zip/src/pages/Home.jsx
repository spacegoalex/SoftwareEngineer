import { useNavigate } from "react-router-dom";

function Home({ goalCalories = 2000, foodCalories = 0, exerciseCalories = 200 }) {
  const navigate = useNavigate();

  const totalFood = foodCalories;
  const remaining = goalCalories - totalFood + exerciseCalories;
  const isOver = remaining < 0;

  return (
    <div className="content" id="home-page">
      <div className="header">
        <div className="profile-pic">👤</div>
        <div>
          <div className="greeting">Hello,</div>
          <div className="user-name">Budi Siregar</div>
        </div>
      </div>

      <div className="card calories-card">
        <div className="calories-message" style={{ color: isOver ? "#D32F2F" : "black" }}>
          {isOver
            ? "⚠️ Anda telah mengonsumsi terlalu banyak kalori hari ini!"
            : "You didn't consume enough calories today."}
        </div>
        <div className="calories-subtitle">
          Remaining = Goal - Food + Exercise
        </div>

        <div className="calories-visual">
          <div
            className="calories-circle"
            style={{
              backgroundColor: isOver ? "#FFCDD2" : "yellow",
              color: isOver ? "#D32F2F" : "black"
            }}
          >
            <div className="calories-number">{remaining}</div>
            <div className="calories-label">Remaining</div>
          </div>

          <div className="calories-breakdown">
            <div className="breakdown-item">
              <div className="goal-dot goal"></div>Goal: {goalCalories}
            </div>
            <div className="breakdown-item">
              <div className="goal-dot exercise"></div>Exercise: {exerciseCalories}
            </div>
            <div className="breakdown-item">
              <div className="goal-dot food"></div>Food: {totalFood}
            </div>
          </div>
        </div>

        <button className="atur-kalori-btn" onClick={() => navigate("/summary")}>
          Atur Kalori <span>→</span>
        </button>
      </div>

      {/* Navigasi ke fitur lainnya */}
      <div className="card calculator-card" onClick={() => navigate("/calorie")}>
        <div className="calculator-icon" style={{ backgroundColor: "#FF9AAA" }}>≡</div>
        <div className="calculator-text">
          <div className="calculator-title">Calorie Calculator</div>
          <div className="calculator-subtitle">Hitung kebutuhan kalori harian Anda dengan informasi pribadi</div>
        </div>
        <div className="arrow-icon">›</div>
      </div>

      <div className="card calculator-card" onClick={() => navigate("/bmi")}>
        <div className="calculator-icon" style={{ backgroundColor: "#A0E7E5" }}>🍎</div>
        <div className="calculator-text">
          <div className="calculator-title">BMI Calculator</div>
          <div className="calculator-subtitle">Menghitung BMI dari data anda</div>
        </div>
        <div className="arrow-icon">›</div>
      </div>

      <div className="card calculator-card" onClick={() => navigate("/activity")}>
        <div className="calculator-icon" style={{ backgroundColor: "#B5EAD7" }}>🏃</div>
        <div className="calculator-text">
          <div className="calculator-title">Daily Activity</div>
          <div className="calculator-subtitle">Lacak aktivitas fisik dan pembakaran kalori Anda hari ini</div>
        </div>
        <div className="arrow-icon">›</div>
      </div>
    </div>
  );
}

export default Home;
